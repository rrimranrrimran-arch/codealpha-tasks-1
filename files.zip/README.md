# Personal Portfolio

A single-file, responsive portfolio site — plain HTML, CSS, and vanilla JavaScript. No build step, no dependencies.

**Design concept:** the page is styled like a set of technical drawing sheets (a "blueprint" aesthetic) — each section is a numbered sheet with corner registration marks, and the contact section doubles as a drafting title block. Fits a developer/engineer persona; the layout is fully responsive and each section is commented for easy editing.

## Files

- `index.html` — everything (markup, styles, script) in one file
- `resume.pdf` — add your own resume here (referenced by the Download button)

## Customize it

Open `index.html` and search for `EDIT ME` comments — they mark every spot you should personalize:

- Your name, role, and location (nav + hero)
- Bio text (About section)
- Skill chips and proficiency bars (Skills section)
- Project cards — title, description, tags, and links (Projects section)
- Work history and education (Resume timeline)
- Email and social links (Contact section)
- `resume.pdf` — drop your actual resume file next to `index.html`

No build tools required — just edit and refresh in a browser.

## Run it locally

Just open `index.html` in a browser, or serve it locally:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploy — GitHub Pages

1. Create a new GitHub repository and push these files:
   ```bash
   git init
   git add .
   git commit -m "Initial portfolio"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
   git push -u origin main
   ```
2. On GitHub, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`.
4. Save. Your site will be live at `https://YOUR-USERNAME.github.io/YOUR-REPO/` within a minute or two.

## Deploy — Netlify

**Option A — drag and drop (fastest):**
1. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag the folder containing `index.html` onto the page.
3. Netlify gives you a live URL immediately. You can rename the site or connect a custom domain from the site dashboard.

**Option B — connect to GitHub (auto-deploys on push):**
1. Push this project to a GitHub repo (see steps above).
2. In Netlify, click **Add new site → Import an existing project**, choose the repo.
3. Leave the build command blank and set the publish directory to `/` (the repo root).
4. Deploy — Netlify will redeploy automatically every time you push.

## Notes

- Animations respect `prefers-reduced-motion`.
- All interactive elements have visible keyboard focus states.
- Fonts (Space Grotesk, IBM Plex Mono, Inter) load from Google Fonts via CDN — no local font files needed.
